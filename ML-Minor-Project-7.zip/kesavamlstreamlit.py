import streamlit as st
import numpy as np
from PIL import Image
import tensorflow as tf

# Load the trained model
model = tf.keras.models.load_model("model.keras")

# Streamlit page configuration
st.set_page_config(page_title="Handwritten Digit Recognition", page_icon="🔢")

# Title
st.title("🔢 Handwritten Digit Recognition using CNN")
st.write("Upload a handwritten digit image (0–9) to predict the digit.")

# Upload image
uploaded_file = st.file_uploader(
    "Choose an image...",
    type=["png", "jpg", "jpeg"]
)

if uploaded_file is not None:

    # Display image
    image = Image.open(uploaded_file).convert("L")
    st.image(image, caption="Uploaded Image", width=200)

    # Preprocess image
    image = image.resize((28, 28))
    image_array = np.array(image)

    # Invert colors if background is white
    if image_array.mean() > 127:
        image_array = 255 - image_array

    image_array = image_array.astype("float32") / 255.0
    image_array = image_array.reshape(1, 28, 28, 1)

    # Predict button
    if st.button("Predict"):

        prediction = model.predict(image_array)

        predicted_digit = np.argmax(prediction)
        confidence = np.max(prediction) * 100

        st.success(f"Predicted Digit: {predicted_digit}")
        st.info(f"Confidence: {confidence:.2f}%")

        st.subheader("Prediction Probabilities")

        for i, prob in enumerate(prediction[0]):
            st.write(f"Digit {i}: {prob*100:.2f}%")

# Sidebar
st.sidebar.title("Project Details")
st.sidebar.write("**Project:** Handwritten Digit Recognition")
st.sidebar.write("**Dataset:** MNIST")
st.sidebar.write("**Algorithm:** Convolutional Neural Network (CNN)")
st.sidebar.write("**Developer:** Kesava Kumar")

st.markdown("---")
st.markdown("Made with ❤️ using TensorFlow and Streamlit")